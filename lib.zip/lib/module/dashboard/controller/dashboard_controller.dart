import 'package:peyekk/core.dart';
import '../view/dashboard_view.dart';

class DashboardController {
  late DashboardView view;
}
