import 'package:peyekk/core.dart';
import '../view/history_view.dart';

class HistoryController {
  late HistoryView view;
}
